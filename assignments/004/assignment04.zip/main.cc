#include "linked_list.hpp"
#include <threads.h>

int user_main(int argc, char *argv[]) {

}

static void work(void *obj) {

}

static void add(void *obj) {

}

static void remove(void *obj) {

}

static void contain(void *obj) {

}
