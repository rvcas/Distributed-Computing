- The assignment was done in "go"
- To run, "go" must be installed and must be in your terminal's or command prompt's path

Steps:
1) cd into the directory with the file "queue.go"
2) type "go run queue.go"
3) a menu will prompt you to type in the number of threads to run on the queue.
4) to exist hit ENTER

Note:
I could have written a separate test module but I just added it as a function in the one file. If I were to import the data structure into a test module it would have made your life more difficult. It would involve configuring go environment variables.
